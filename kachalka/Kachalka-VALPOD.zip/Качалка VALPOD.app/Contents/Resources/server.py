#!/usr/bin/env python3
# Качалка VALPOD — локальный сервер. Работает только на 127.0.0.1.
import json, os, re, subprocess, threading, time, uuid, unicodedata
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse

VERSION = "1.0"
PORT = 8765
HERE = Path(__file__).resolve().parent
HOME = Path.home()
DESKTOP = HOME / "Desktop"
SUP = HOME / "Library/Application Support/VALPOD Kachalka"
BIN = SUP / "bin"
CFG = SUP / "config.json"
YTDLP = str(BIN / "yt-dlp")
TEMPLATE_DIRS = {"AE", "FOOTAGE", "IMG", "MUS", "PRJ", "REF", "RENDER", "SFX", "TXT", "VIDEO", "VOICE"}
COOKIE_SITES = ("instagram.com", "facebook.com", "fb.watch", "x.com", "twitter.com",
                "tiktok.com", "vk.com", "vkvideo.ru", "pinterest.")
ANSI = re.compile(r"\x1b\[[0-9;]*m")

ENV = os.environ.copy()
ENV["PATH"] = f"{BIN}:/opt/homebrew/bin:/usr/local/bin:" + ENV.get("PATH", "/usr/bin:/bin")

QUALITY = {
    "edit":  ["-f", "bv*+ba/b", "-S", "vcodec:h264,res,acodec:aac", "--merge-output-format", "mp4"],
    "max":   ["-f", "bv*+ba/b", "-S", "res,fps,br", "--merge-output-format", "mp4"],
    "1080":  ["-f", "bv*+ba/b", "-S", "res:1080,vcodec:h264,acodec:aac", "--merge-output-format", "mp4"],
    "audio": ["-f", "ba/b", "-x", "--audio-format", "mp3", "--audio-quality", "0"],
}

lock = threading.Lock()
JOBS = {}
last_seen = time.time()


def nfc(s):
    return unicodedata.normalize("NFC", s)


def load_cfg():
    try:
        return json.loads(CFG.read_text("utf-8"))
    except Exception:
        return {}


def save_cfg(c):
    SUP.mkdir(parents=True, exist_ok=True)
    CFG.write_text(json.dumps(c, ensure_ascii=False, indent=1), "utf-8")


def label_for(p: Path):
    try:
        rel = p.relative_to(DESKTOP)
        parts = [nfc(x) for x in rel.parts]
        if parts and parts[0].upper() == "КЛИЕНТЫ":
            parts = parts[1:]
        return " / ".join(parts) or "Рабочий стол"
    except ValueError:
        return nfc(str(p).replace(str(HOME), "~"))


def subdirs(d):
    try:
        return [Path(e.path) for e in os.scandir(d)
                if e.is_dir(follow_symlinks=False) and not e.name.startswith(".")]
    except Exception:
        return []


def ref_of(d: Path):
    for c in subdirs(d):
        if c.name.upper() == "REF":
            return c
    return None


def scan_projects():
    found = {}

    def add(proj: Path):
        if str(proj) in found:
            return
        ref = ref_of(proj)
        try:
            mt = proj.stat().st_mtime
        except Exception:
            mt = 0
        found[str(proj)] = {"target": str(ref or proj / "REF"), "label": label_for(proj),
                            "hasRef": bool(ref), "mtime": mt}

    def walk(d: Path, depth):
        if depth > 3:
            return
        kids = subdirs(d)
        if d != DESKTOP and any(k.name.upper() == "REF" for k in kids):
            add(d)
            return
        for k in kids:
            n = k.name
            if n.upper() in TEMPLATE_DIRS or n.endswith((".app", ".prproj", ".aep", ".fcpbundle")):
                continue
            walk(k, depth + 1)

    walk(DESKTOP, 0)
    for k in subdirs(DESKTOP):
        if nfc(k.name).upper() == "КЛИЕНТЫ":
            for client in subdirs(k):
                for proj in subdirs(client):
                    if proj.name.upper() not in TEMPLATE_DIRS:
                        add(proj)
    for root in load_cfg().get("roots", []):
        walk(Path(root), 1)

    recent = load_cfg().get("recent", [])
    items = list(found.values())
    known = {i["target"] for i in items}
    for r in recent:
        if r not in known and Path(r).exists():
            items.append({"target": r, "label": label_for(Path(r)), "hasRef": True, "mtime": 0})
    if not items:
        dl = HOME / "Downloads" / "Качалка VALPOD"
        items.append({"target": str(dl), "label": "Загрузки / Качалка VALPOD", "hasRef": False, "mtime": 0})
    rank = {r: i for i, r in enumerate(recent)}
    items.sort(key=lambda i: (rank.get(i["target"], 999), -i["mtime"]))
    return items


def remember_target(t):
    c = load_cfg()
    rec = [t] + [x for x in c.get("recent", []) if x != t]
    c["recent"] = rec[:12]
    save_cfg(c)


def needs_cookies(url):
    host = (urlparse(url).hostname or "").lower()
    return any(s in host for s in COOKIE_SITES)


def run_job(job, use_cookies=True):
    target = job["target"]
    Path(target).mkdir(parents=True, exist_ok=True)
    args = [YTDLP, "--newline", "--progress", "--quiet", "--no-simulate", "--color", "never",
            "--no-playlist", "--no-mtime", "--windows-filenames",
            "--progress-template", "download:[[P]]%(progress._percent_str)s|%(progress._speed_str)s|%(progress._eta_str)s",
            "--print", "before_dl:[[T]]%(title)s",
            "--print", "after_move:[[F]]%(filepath)s",
            "-P", target, "-o", "%(title).90B.%(ext)s"]
    if (BIN / "ffmpeg").exists():
        args += ["--ffmpeg-location", str(BIN)]
    args += QUALITY.get(job["quality"], QUALITY["edit"])
    browser = job.get("browser") or "none"
    cookies = use_cookies and browser != "none" and needs_cookies(job["url"])
    if cookies:
        args += ["--cookies-from-browser", browser]
    args.append(job["url"])

    job.update(status="running", percent=0, error="", note="Подключаюсь…")
    errors, last_pct = [], 0.0
    try:
        p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             env=ENV, text=True, bufsize=1)
        job["pid"] = p.pid
        for raw in p.stdout:
            line = ANSI.sub("", raw).strip()
            if line.startswith("[[T]]"):
                job["title"] = line[5:]
                job["note"] = "Качаю…"
            elif line.startswith("[[P]]"):
                pct, speed, eta = (line[5:].split("|") + ["", "", ""])[:3]
                try:
                    v = float(pct.strip().rstrip("%"))
                except ValueError:
                    continue
                if v < last_pct - 20:
                    job["part"] = job.get("part", 1) + 1
                last_pct = v
                job["percent"] = v
                part = " · звук" if job.get("part", 1) > 1 and job["quality"] != "audio" else ""
                job["note"] = f"{speed.strip()} · осталось {eta.strip()}{part}" if v < 100 else "Склеиваю…"
            elif line.startswith("[[F]]"):
                job["file"] = line[5:]
            elif "ERROR" in line:
                errors.append(line.replace("ERROR:", "").strip())
        code = p.wait()
    except Exception as e:
        code, errors = 1, [str(e)]

    if job.get("cancel"):
        job.update(status="error", error="Отменено", note="")
        return
    if code == 0 and job.get("file"):
        job.update(status="done", percent=100, note="Готово")
        remember_target(target)
        return
    if cookies:
        job["note"] = "Пробую без входа в аккаунт…"
        return run_job(job, use_cookies=False)
    job.update(status="error", note="", error=(errors[-1] if errors else f"Код ошибки {code}")[:400])


def start_job(url, target, quality, browser):
    jid = uuid.uuid4().hex[:8]
    job = {"id": jid, "url": url, "target": target, "targetLabel": label_for(Path(target)),
           "quality": quality, "browser": browser, "status": "queued", "percent": 0,
           "title": url, "note": "В очереди", "created": time.time()}
    with lock:
        JOBS[jid] = job
    threading.Thread(target=run_job, args=(job,), daemon=True).start()
    return job


def auto_update():
    c = load_cfg()
    if time.time() - c.get("last_update", 0) < 20 * 3600:
        return
    try:
        subprocess.run([YTDLP, "-U"], env=ENV, capture_output=True, timeout=180)
        c = load_cfg(); c["last_update"] = time.time(); save_cfg(c)
    except Exception:
        pass


def idle_watch():
    while True:
        time.sleep(60)
        busy = any(j["status"] in ("queued", "running") for j in JOBS.values())
        if not busy and time.time() - last_seen > 3 * 3600:
            os._exit(0)


def pick_folder():
    script = 'POSIX path of (choose folder with prompt "Куда сохранять видео?")'
    r = subprocess.run(["osascript", "-e", 'tell application "System Events" to activate',
                        "-e", f'tell application "System Events" to return {script}'],
                       capture_output=True, text=True)
    return r.stdout.strip().rstrip("/") or None


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _host_ok(self):
        return self.headers.get("Host", "") in (f"127.0.0.1:{PORT}", f"localhost:{PORT}")

    def do_GET(self):
        global last_seen
        last_seen = time.time()
        if not self._host_ok():
            return self._send(403, {"error": "host"})
        path = self.path.split("?")[0]
        if path in ("/", "/index.html"):
            return self._send(200, (HERE / "index.html").read_bytes(), "text/html; charset=utf-8")
        if path == "/icon.png" and (HERE / "icon.png").exists():
            return self._send(200, (HERE / "icon.png").read_bytes(), "image/png")
        if path == "/api/ping":
            return self._send(200, {"ok": True, "version": VERSION})
        if path == "/api/folders":
            return self._send(200, {"folders": scan_projects()})
        if path == "/api/settings":
            c = load_cfg()
            return self._send(200, {"browser": c.get("browser", "chrome"), "quality": c.get("quality", "edit"),
                                    "target": (c.get("recent") or [None])[0]})
        if path == "/api/jobs":
            with lock:
                jobs = sorted(JOBS.values(), key=lambda j: -j["created"])[:40]
            return self._send(200, {"jobs": [{k: v for k, v in j.items() if k != "pid"} for j in jobs]})
        self._send(404, {"error": "not found"})

    def do_POST(self):
        global last_seen
        last_seen = time.time()
        if not self._host_ok() or self.headers.get("X-Kachalka") != "1":
            return self._send(403, {"error": "forbidden"})
        try:
            n = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            body = {}
        path = self.path.split("?")[0]

        if path == "/api/download":
            target = body.get("target") or ""
            if not target:
                return self._send(400, {"error": "Выбери папку"})
            urls = [u.strip() for u in re.split(r"[\s,]+", body.get("urls", "")) if u.strip().startswith("http")]
            if not urls:
                return self._send(400, {"error": "Не вижу ссылку"})
            q, b = body.get("quality", "edit"), body.get("browser", "chrome")
            c = load_cfg(); c["quality"], c["browser"] = q, b; save_cfg(c)
            jobs = [start_job(u, target, q, b) for u in urls]
            return self._send(200, {"ids": [j["id"] for j in jobs]})
        if path == "/api/pick":
            p = pick_folder()
            if p:
                remember_target(p)
            return self._send(200, {"path": p, "label": label_for(Path(p)) if p else None})
        if path == "/api/reveal":
            f = body.get("path", "")
            if f and Path(f).exists():
                subprocess.Popen(["open", "-R", f])
            return self._send(200, {"ok": True})
        if path == "/api/cancel":
            j = JOBS.get(body.get("id", ""))
            if j and j.get("pid") and j["status"] == "running":
                j["cancel"] = True
                try:
                    os.kill(j["pid"], 15)
                except Exception:
                    pass
            return self._send(200, {"ok": True})
        if path == "/api/clear":
            with lock:
                for k in [k for k, j in JOBS.items() if j["status"] in ("done", "error")]:
                    JOBS.pop(k)
            return self._send(200, {"ok": True})
        if path == "/api/quit":
            self._send(200, {"ok": True})
            threading.Timer(0.3, lambda: os._exit(0)).start()
            return
        self._send(404, {"error": "not found"})


if __name__ == "__main__":
    SUP.mkdir(parents=True, exist_ok=True)
    threading.Thread(target=auto_update, daemon=True).start()
    threading.Thread(target=idle_watch, daemon=True).start()
    first = HERE / "first.json"
    if first.exists():
        try:
            f = json.loads(first.read_text("utf-8"))
            first.unlink()
            start_job(f["url"], f["target"], f.get("quality", "edit"), "none")
        except Exception:
            pass
    ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()
