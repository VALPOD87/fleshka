#!/bin/bash
# Качалка VALPOD — установка (один раз)
SUP="$HOME/Library/Application Support/VALPOD Kachalka"; BIN="$SUP/bin"; T="$(mktemp -d)"
mkdir -p "$BIN"
RES="$(cd "$(dirname "$0")" && pwd)"
clear
echo "  ┌──────────────────────────────────────┐"
echo "  │   Качалка VALPOD — первая установка  │"
echo "  └──────────────────────────────────────┘"
echo "  Ставлю загрузчик, ffmpeg и движок для YouTube. Это 1–3 минуты."
echo
if [ "$(uname -m)" = "arm64" ]; then DA=aarch64; FA=arm64; else DA=x86_64; FA=amd64; fi
dl(){ curl -fL --retry 3 --progress-bar -o "$2" "$1"; }
fail(){ echo; echo "  ✗ $1"; echo "  Сделай скриншот этого окна и пришли в Telegram @valpod."; read -n1 -p "  Нажми любую клавишу…"; exit 1; }

echo "→ yt-dlp (загрузчик)"
[ -x "$BIN/yt-dlp" ] || { dl https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos "$BIN/yt-dlp" && chmod +x "$BIN/yt-dlp"; } || fail "Не скачался yt-dlp"

echo "→ deno (нужен YouTube)"
if [ ! -x "$BIN/deno" ]; then
  dl "https://github.com/denoland/deno/releases/latest/download/deno-$DA-apple-darwin.zip" "$T/deno.zip" && unzip -oq "$T/deno.zip" -d "$BIN" && chmod +x "$BIN/deno" || fail "Не скачался deno"
fi

for t in ffmpeg ffprobe; do
  echo "→ $t"
  [ -x "$BIN/$t" ] && continue
  if [ -x "/opt/homebrew/bin/$t" ]; then ln -sf "/opt/homebrew/bin/$t" "$BIN/$t"; continue; fi
  if [ -x "/usr/local/bin/$t" ]; then ln -sf "/usr/local/bin/$t" "$BIN/$t"; continue; fi
  dl "https://ffmpeg.martin-riedl.de/redirect/latest/macos/$FA/release/$t.zip" "$T/$t.zip" && unzip -oq "$T/$t.zip" -d "$BIN" && chmod +x "$BIN/$t" || fail "Не скачался $t"
done
xattr -dr com.apple.quarantine "$BIN" 2>/dev/null

echo "→ python"
if xcode-select -p >/dev/null 2>&1 && /usr/bin/python3 -c 'import sys; assert sys.version_info >= (3, 8)' 2>/dev/null; then
  PY=/usr/bin/python3
else
  dl "https://github.com/astral-sh/uv/releases/latest/download/uv-$DA-apple-darwin.tar.gz" "$T/uv.tgz" && tar -xzf "$T/uv.tgz" -C "$BIN" --strip-components 1 || fail "Не скачался uv"
  "$BIN/uv" python install 3.12 >/dev/null 2>&1 || fail "Не поставился python"
  PY="$("$BIN/uv" python find 3.12)"
fi
echo "$PY" > "$SUP/python_path"

echo
echo "  Проверка:"
"$BIN/yt-dlp" --version >/dev/null 2>&1 && echo "  ✓ yt-dlp $("$BIN/yt-dlp" --version)" || fail "yt-dlp не запускается"
"$BIN/ffmpeg" -version >/dev/null 2>&1 && echo "  ✓ ffmpeg" || fail "ffmpeg не запускается"
"$BIN/deno" --version >/dev/null 2>&1 && echo "  ✓ deno" || fail "deno не запускается"
"$PY" -c 'print()' >/dev/null 2>&1 && echo "  ✓ python" || fail "python не запускается"
touch "$SUP/ready"
rm -rf "$T"
echo
echo "  Готово! Открываю качалку в браузере. Это окно можно закрыть."
"$RES/../MacOS/Kachalka"
sleep 2
